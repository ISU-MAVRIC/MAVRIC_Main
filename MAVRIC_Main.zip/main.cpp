#include "mbed.h"
#include "RingBuffer.h"
#include "PID.h"

//#define NO_PACKET 0
//#define MOTOR_SPEED 1
//#define ARM_CONTROL 2
//#define CAM_GIMBAL 3

PwmOut arm_rotate(D13); //PA_5
int arm_rotate_speed;

PwmOut arm_shoulder(D12); //PA_6
AnalogIn arm_shoulder_fdbk(A0);
int arm_shoulder_speed;
//PID arm_shoulder_pid(1,1,1,1);
//float arm_shoulder_sp = .5;

PwmOut arm_elbow(D11);  //PA_7
AnalogIn arm_elbow_fdbk(A1);
int arm_elbow_speed;
//PID arm_elbow_pid(1,1,1,1);
//float arm_elbow_sp = .5;

PwmOut wheel_left(D15); //PB_8
int wheel_left_speed;
PwmOut wheel_right(D14); //PB_9
int wheel_right_speed;

PwmOut cam_pan(D10); //PB_6
PwmOut cam_tilt(D9); //PC_7

RingBuffer *txBuffer;
RingBuffer *rxBuffer;

Serial ser(USBTX, USBRX);

char buf[32];
int packet_length;
bool packet_ready = false;
//int packet_type = NO_PACKET;

void initialize_PWM()
{
    arm_rotate.period_ms(20);
    arm_rotate.pulsewidth_us(1500);
    arm_shoulder.period_ms(20);
    arm_shoulder.pulsewidth_us(1500);
    arm_elbow.period_ms(20);
    arm_elbow.pulsewidth_us(1500);

    wheel_left.period_ms(20);
    wheel_left.pulsewidth_us(1500);
    wheel_right.period_ms(20);
    wheel_right.pulsewidth_us(1500);

    cam_pan.period_ms(20);
    cam_pan.pulsewidth_us(1500);
    cam_tilt.period_ms(20);
    cam_tilt.pulsewidth_us(1500);
}

//void initialize_PID()
//{
//    arm_shoulder_pid.setInputLimits(0, 1);
//    arm_shoulder_pid.setOutputLimits(1000, 2000);
//    //arm_elbow_pid.setInputLimits(0, 1);
//    //arm_elbow_pid.setOutputLimits(0, 255);
//}

//void update_PID()
//{
//    float shoulder_pos = arm_shoulder_fdbk.read();
//    //float elbow_pos = arm_elbow_fdbk.read();
//    arm_shoulder_pid.setProcessValue(shoulder_pos);
//    arm_shoulder_pid.setSetPoint(arm_shoulder_sp);
//    int shoulder_output = arm_shoulder_pid.compute();
//    //arm_shoulder.pulsewidth_us(shoulder_output);
//    ///ser.printf("SP: %.4f\tPos: %.4f\tOP: %d\n", arm_shoulder_sp, shoulder_pos, shoulder_output);
//}


int map(int x, int in_min, int in_max, int out_min, int out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int angle_to_us(float angle)
{
    return (int) ((((angle) * (float) 1000) / (float) 180) + (float)1000);
}

void process_serial()
{
    if(ser.readable()) {
        char c = ser.getc();
        rxBuffer->write(c);
        if(c == '>') {
            while(!rxBuffer->isEmpty() && !packet_ready) {
                char r = rxBuffer->read();
                if(r == '<') {
                    packet_ready = true;
                }
            }
        }
    }
}

void process_packet()
{
    buf[0] = '<';
    packet_length = 1;
    char c = '\0';
    int i = 1;
    while(c != '>') {
        c = rxBuffer->read();
        buf[i] = c;
        i++;
        packet_length++;
    }
    buf[i++] = '\0';
    //ser.printf(" %s Length:%d\n", buf, packet_length);
    //rxBuffer->empty();
    //ser.printf("%d",packet_length);
    packet_ready = false;
}

void motor_status_packet()
{
    ser.printf("<sm%c%c%c%c%c%c>", wheel_left_speed, wheel_left_speed, wheel_left_speed, 
        wheel_right_speed, wheel_right_speed, wheel_right_speed);
}

void motor_control_packet()
{
    //ser.printf("Motor Control\n");
    wheel_left_speed = buf[3];
    wheel_right_speed = buf[6];
    //ser.printf("Left: %d\tRight: %d\n", left_speed, right_speed);
    int left_us = map(wheel_left_speed, 0, 255, 1000, 2000);
    int right_us = map(wheel_right_speed, 0, 255, 1000, 2000);
    //ser.printf("Left: %d\tRight: %d\n", left_us, right_us);

    wheel_left.pulsewidth_us(left_us);
    wheel_right.pulsewidth_us(right_us);
    
    //control software expects a status packet now
    motor_status_packet();
}

void arm_status_packet()
{
    ser.printf("<sa%c%c%c>", arm_rotate_speed, arm_shoulder_speed, arm_elbow_speed);
}

void arm_control_packet()
{
    //CODE FOR PID
    //ser.printf("Arm Control Packet\n");
    //int shoulder_pos = buf[4] | buf[3] << 8;
    //int elbow_pos = buf[6] | buf[5] <<8;
    //ser.printf("SP: %d   EP: %d\n", shoulder_pos, elbow_pos);
    //arm_shoulder_sp = ((float) atoi(shoulder_pos_str)) / ((float) 1000);
    //arm_elbow_sp = ((float) atoi(elbow_pos_str)) / ((float) 1000);
    //ser.printf("Shoulder SP: %.4f     Elbow SP: %.4f\n", arm_shoulder_sp, arm_elbow_sp);
    
    arm_rotate_speed = buf[3];
    arm_shoulder_speed = buf[4];
    arm_elbow_speed = buf[5];
    
    int rotate_us = map(arm_rotate_speed, 0, 255, 1000, 2000);
    int shoulder_us = map(arm_shoulder_speed, 0, 255, 1000, 2000);
    int elbow_us = map(arm_elbow_speed, 0, 255, 1000, 2000);
    
    arm_rotate.pulsewidth_us(rotate_us);
    arm_shoulder.pulsewidth_us(shoulder_us);
    arm_elbow.pulsewidth_us(elbow_us);
    
    arm_status_packet();
}
    
//literally copy pasted from above, plz change this is temporary
void camera_gimbal_packet()
{
    ser.printf("Camera Gimbal Control\n");
    char left_speed_str[3] = { buf[3], buf[4], buf[5] };
    char right_speed_str[3] = { buf[6], buf[7], buf[8] };
    int left_speed = atoi(left_speed_str);
    int right_speed = atoi(right_speed_str);
    ser.printf("Left: %d\tRight: %d\n", left_speed, right_speed);
    int left_us = map(left_speed, 0, 255, 1000, 2000);
    int right_us = map(right_speed, 0, 255, 1000, 2000);
    ser.printf("Left: %d\tRight: %d\n", left_us, right_us);

    cam_pan.pulsewidth_us(left_us);
    cam_tilt.pulsewidth_us(right_us);
}

void parse_packet()
{
    char type[2] = { buf[1], buf[2] };
    //motor control
    if((strcmp(type, "cm") == 0) && packet_length == 10) {
        motor_control_packet();
    }
    if((strcmp(type, "ca") == 0) && packet_length == 7) {
        arm_control_packet();
    }

}




int main()
{
    initialize_PWM();

    rxBuffer = new RingBuffer(64);
    ser.baud(57600);

    while(1) {
        process_serial();
//        arm_status_packet();
        if(packet_ready) {
            process_packet();
            parse_packet();
        }
//        update_PID();
    }
}